'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  return (
    <div className="relative min-h-screen w-full bg-slate-50 flex items-center justify-center font-sans p-4 overflow-hidden">
      
      {/* 1. Background Video DNA */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-cover opacity-50 mix-blend-luminosity"
        >
          <source src="/dna-bg-video.mp4" type="video/mp4" />
          Browser Anda tidak mendukung tag video.
        </video>
        
        {/* Overlay putih ditipiskan (30% opacity) dan blurnya dikurangi */}
        <div className="absolute inset-0 bg-white/30 backdrop-blur-[1px]"></div>
      </div>

      {/* 2. Card UI Glassmorphism */}
      <div className="relative z-10 w-full max-w-md bg-white/70 border border-white/80 backdrop-blur-2xl rounded-[2rem] p-8 shadow-[0_10px_40px_rgba(0,0,0,0.08)] space-y-6">
        
        {/* Header Section */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-2 bg-white/80 rounded-xl backdrop-blur-md border border-slate-100 shadow-sm">
              <img src="/GenoSphere Logo.png" alt="GenoSphere Logo" className="h-8 w-auto object-contain" />
            </div>
            <span className="font-bold text-2xl tracking-wide bg-gradient-to-r from-blue-600 via-indigo-600 to-emerald-600 bg-clip-text text-transparent">
              GenoSphere
            </span>
          </div>
          <h1 className="text-2xl font-bold text-slate-800 tracking-tight">Lupa Kata Sandi?</h1>
          <p className="text-sm text-slate-500">
            {isSubmitted
              ? 'Tautan pemulihan telah dikirim ke email Anda.'
              : 'Masukkan email terdaftar Anda untuk pemulihan.'}
          </p>
        </div>

        {/* Form Section */}
        {!isSubmitted ? (
          <form onSubmit={handleSubmit} className="space-y-5 mt-4">
            <div className="space-y-1.5">
              <label className="block text-sm text-slate-700 font-semibold ml-1">Alamat Email</label>
              <div className="relative">
                <input
                  type="email"
                  required
                  placeholder="peneliti@institusi.ac.id"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-white/90 border border-slate-200 rounded-xl px-4 py-3 text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all duration-300 shadow-sm"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full relative group overflow-hidden rounded-xl font-semibold py-3 transition-all duration-300 transform hover:-translate-y-0.5 shadow-[0_8px_20px_rgba(37,99,235,0.2)] hover:shadow-[0_10px_25px_rgba(16,185,129,0.25)]"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600 via-indigo-500 to-emerald-500 opacity-90 group-hover:opacity-100 transition-opacity duration-300"></div>
              <span className="relative text-white text-sm tracking-wide">Kirim Tautan Pemulihan</span>
            </button>
          </form>
        ) : (
          <div className="relative overflow-hidden bg-emerald-50 border border-emerald-200 rounded-2xl p-5 text-center mt-4 shadow-sm">
            <p className="text-sm text-emerald-800 relative z-10 leading-relaxed">
              Silakan periksa kotak masuk email <br/>
              <span className="font-bold text-emerald-950 text-base mt-1 block">{email}</span> 
              <br/>dan ikuti petunjuk selanjutnya.
            </p>
          </div>
        )}

        <div className="text-center pt-6 mt-6 border-t border-slate-200">
          <Link href="/login" className="text-sm text-slate-500 hover:text-blue-600 font-medium inline-flex items-center gap-2 transition-colors group">
            <span className="group-hover:-translate-x-1 transition-transform duration-300">←</span>
            Kembali ke Halaman Masuk
          </Link>
        </div>

      </div>
    </div>
  );
}