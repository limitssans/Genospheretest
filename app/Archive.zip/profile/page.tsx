'use client';

import Link from 'next/link';
import { usePipelineStore } from '@/store/usePipelineStore';

export default function ProfilePage() {
  const { userProfile } = usePipelineStore();

  const getUserName = () => {
    if (userProfile?.fullName) return userProfile.fullName;
    if (userProfile?.email) {
      const namePart = userProfile.email.split('@')[0];
      return namePart
        .split(/[._-]/)
        .map((s) => s.charAt(0).toUpperCase() + s.slice(1))
        .join(' ');
    }
    return 'Nama Pengguna';
  };

  const getUserInitial = () => {
    const name = getUserName();
    return name.charAt(0).toUpperCase();
  };

  return (
    <div 
      suppressHydrationWarning 
      className="relative min-h-screen w-full bg-slate-50 flex flex-col justify-between overflow-x-hidden font-sans p-6 md:p-10"
    >
      {/* 1. Background Video DNA */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-cover opacity-50 mix-blend-luminosity"
        >
          <source src="/dna-bg-video.mp4" type="video/mp4" />
          Browser Anda tidak mendukung tag video.
        </video>
        <div className="absolute inset-0 bg-white/30 backdrop-blur-[1px]"></div>
      </div>

      <div className="relative z-10 max-w-3xl mx-auto w-full space-y-6 my-auto">
        {/* HEADER NAVIGATION BACK */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-800 tracking-tight">Profil Pengguna</h1>
            <p className="text-sm text-slate-600 mt-1">Informasi akun peneliti yang terhubung ke pipeline GenoSphere-GWAS.</p>
          </div>
          <Link 
            href="/pipeline/step-1" 
            className="px-4 py-2.5 bg-white/70 hover:bg-white text-slate-700 text-xs font-semibold rounded-xl transition-all duration-300 border border-white shadow-sm hover:shadow-md flex items-center gap-2 backdrop-blur-md"
          >
            ← Kembali ke Pipeline
          </Link>
        </div>

        {/* KARTU PROFIL READ-ONLY (GLASSMORPHISM) */}
        <div className="bg-white/70 border border-white/80 backdrop-blur-2xl rounded-[2rem] p-8 shadow-[0_10px_40px_rgba(0,0,0,0.08)] space-y-6">
          
          {/* HEADER AVATAR & NAMA */}
          <div className="flex items-center gap-6 pb-6 border-b border-white/50">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-600 via-indigo-600 to-emerald-600 text-white flex items-center justify-center font-bold text-3xl shadow-lg shadow-blue-600/30 shrink-0">
              {getUserInitial()}
            </div>
            <div>
              <h2 className="text-2xl font-extrabold text-slate-800 tracking-tight">
                {getUserName()}
              </h2>
              <p className="text-sm font-bold bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent mt-0.5">
                @{userProfile?.username || (userProfile?.email ? userProfile.email.split('@')[0] : 'username')}
              </p>
            </div>
          </div>

          {/* DETAIL INFORMASI AKUN */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs">
            
            <div className="bg-white/80 border border-white rounded-xl p-4 shadow-sm space-y-1.5 transition hover:shadow-md">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                Nama Lengkap
              </span>
              <p className="text-sm font-semibold text-slate-800">
                {getUserName()}
              </p>
            </div>

            <div className="bg-white/80 border border-white rounded-xl p-4 shadow-sm space-y-1.5 transition hover:shadow-md">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                Username
              </span>
              <p className="text-sm font-semibold text-slate-800">
                @{userProfile?.username || (userProfile?.email ? userProfile.email.split('@')[0] : 'peneliti')}
              </p>
            </div>

            <div className="bg-white/80 border border-white rounded-xl p-4 shadow-sm space-y-1.5 md:col-span-2 transition hover:shadow-md">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                Alamat Email
              </span>
              <p className="text-sm font-semibold text-slate-800 font-mono">
                {userProfile?.email || 'peneliti@ipb.ac.id'}
              </p>
            </div>

            <div className="bg-white/80 border border-white rounded-xl p-4 shadow-sm space-y-1.5 md:col-span-2 transition hover:shadow-md">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                Institusi & Program Studi
              </span>
              <p className="text-sm font-semibold text-slate-800">
                {userProfile?.institution || 'Program Studi Bioinformatika, FMIPA, IPB University'}
              </p>
            </div>

            <div className="bg-white/80 border border-white rounded-xl p-4 shadow-sm space-y-1.5 md:col-span-2 transition hover:shadow-md">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                Bio / Bidang Penelitian
              </span>
              <p className="text-sm text-slate-700 leading-relaxed font-medium">
                {userProfile?.bio || 'Peneliti analisis genomik dan variasi genetik GWAS.'}
              </p>
            </div>

          </div>

          {/* STATUS INTEGRASI */}
          <div className="p-4 bg-blue-50/80 border border-blue-100/50 backdrop-blur-md rounded-xl flex items-center gap-3 text-xs text-blue-900 font-medium">
            <span className="text-blue-600 text-lg">ℹ️</span>
            <span>Data profil ini tersinkronisasi otomatis dengan akun sesi aktif dan email login Anda.</span>
          </div>

        </div>
      </div>
    </div>
  );
}